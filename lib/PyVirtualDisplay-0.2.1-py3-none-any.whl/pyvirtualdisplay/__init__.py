import logging

from pyvirtualdisplay.display import Display
from pyvirtualdisplay.about import __version__


log = logging.getLogger(__name__)

log = logging.getLogger(__name__)
log.debug('version=%s', __version__)
